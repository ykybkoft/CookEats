package com.project.cookEats.recipe.openapi;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OpenApiRepository extends JpaRepository<Board_recipe, Long> {
}