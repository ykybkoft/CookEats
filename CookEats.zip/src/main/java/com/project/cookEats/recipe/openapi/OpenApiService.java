package com.project.cookEats.recipe.openapi;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@Service
public class OpenApiService {

    @Autowired
    private OpenApiRepository repository;

    private final WebClient webClient;
    private final ObjectMapper objectMapper;

    @Value("${api.openapi.key}")
    private String apiKey;

    @Value("${api.openapi.serviceName}")
    private String serviceName;

    @Value("${api.openapi.delayMillis}")
    private long delayMillis;

    @Value("${api.openapi.start}")
    private int start;

    @Value("${api.openapi.end}")
    private int end;

    @Autowired
    public OpenApiService() {
        this.webClient = WebClient.builder().baseUrl("http://openapi.foodsafetykorea.go.kr/api/").build();
        this.objectMapper = new ObjectMapper();
    }

    public void fetchData() {
        fetchDataRecursive(start, end);
    }

    private void fetchDataRecursive(int start, int end) {
        String url = String.format("/%s/%s/%d/%d", apiKey, serviceName, start, Math.min(start + 99, end));

        Mono<String> response = webClient.get().uri(url).retrieve().bodyToMono(String.class);
        response.subscribe(json -> {
            try {
                JsonNode rootNode = objectMapper.readTree(json);
                JsonNode dataList = rootNode.path("COOKRCP01").path("row");  // API에서 실제 데이터가 있는 경로로 수정 필요

                List<Board_recipe> recipes = new ArrayList<>();
                for (JsonNode node : dataList) {
                    Board_recipe recipe = objectMapper.treeToValue(node, Board_recipe.class);
                    recipes.add(recipe);
                }
                repository.saveAll(recipes);

                if (start + 100 <= end) {
                    // 동적 대기 시간 적용 후 다음 요청
                    Thread.sleep(delayMillis);
                    fetchDataRecursive(start + 100, end);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}